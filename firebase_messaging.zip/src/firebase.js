import { initializeApp } from "firebase/app";
import { getMessaging } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyDdvHxuS7vpW_NV_fT9RGfFxodTeJNMJTc",
  authDomain: "pushnotification-96fbc.firebaseapp.com",
  projectId: "pushnotification-96fbc",
  storageBucket: "pushnotification-96fbc.appspot.com",
  messagingSenderId: "628636297708",
  appId: "1:628636297708:web:a7261f782307dfc22a38c9",
};

export const app = initializeApp(firebaseConfig);
export const messaging = getMessaging(app);
