importScripts("https://www.gstatic.com/firebasejs/8.10.0/firebase-app.js");
importScripts(
  "https://www.gstatic.com/firebasejs/8.10.0/firebase-messaging.js"
);

const firebaseConfig = {
  apiKey: "AIzaSyDdvHxuS7vpW_NV_fT9RGfFxodTeJNMJTc",
  authDomain: "pushnotification-96fbc.firebaseapp.com",
  projectId: "pushnotification-96fbc",
  storageBucket: "pushnotification-96fbc.appspot.com",
  messagingSenderId: "628636297708",
  appId: "1:628636297708:web:a7261f782307dfc22a38c9",
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  console.log(
    "[firebase-messaging-sw.js] Received background message ",
    payload
  );
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: payload.notification.image,
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
